import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faUser, faEnvelope } from '@fortawesome/free-solid-svg-icons';

const Header = ({ onAboutClick }) => {
    return (
        <header className="header">
            <div className="logo">Innovate</div>
            <nav>
                <button className="nav-button">
                    <FontAwesomeIcon icon={faHome} /> Home
                </button>
               
                <button className="nav-button" onClick={() => console.log('About button clicked!')}>
                    <FontAwesomeIcon icon={faUser} /> About
                </button>
                <button className="nav-button">
                    <FontAwesomeIcon icon={faEnvelope} /> Contact
                </button>
            </nav>
        </header>
    );
};

export default Header;

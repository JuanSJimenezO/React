import React from 'react';

const AboutMe = ({ isVisible, onClose }) => {
    console.log('Rendering AboutMe component, isVisible:', isVisible); // Depuración

    if (!isVisible) return null; // No se renderiza si isVisible es false

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <button className="close-button" onClick={onClose}>
                    &times;
                </button>
                <h2>About Me</h2>
                <img
                    src="https://via.placeholder.com/150"
                    alt="Profile"
                    className="profile-picture"
                />
                <p>
                    Hi, I'm [Your Name]! I'm passionate about creating innovative solutions and building
                    modern, user-friendly interfaces. I specialize in web development and enjoy learning
                    new technologies.
                </p>
            </div>
        </div>
    );
};

export default AboutMe;
